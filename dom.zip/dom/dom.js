
// Задание 1
const input1 = document.getElementById('input1');
const paragraph1 = document.getElementById('paragraph1');

input1.addEventListener('blur', function() {
    paragraph1.textContent += input1.value;
});

// Задание 2
const inputs2 = document.querySelectorAll('.input2');
const button2 = document.getElementById('button2');
const result2 = document.getElementById('result2');

button2.addEventListener('click', function() {
    let sum = 0;
    inputs2.forEach(input => {
        sum += parseFloat(input.value) || 0;
    });
    result2.textContent = `Sum: ${sum}`;
});

// Задание 3
const input3 = document.getElementById('input3');
const result3 = document.getElementById('result3');

input3.addEventListener('blur', function() {
    const number = input3.value;
    let sum = 0;
    for (let digit of number) {
        sum += parseInt(digit) || 0;
    }
    result3.textContent = `Сумма цифр: ${sum}`;
});

// Задание 4
const input4 = document.getElementById('input4');
const result4 = document.getElementById('result4');

input4.addEventListener('blur', function() {
    const numbers = input4.value.split(',').map(num => parseFloat(num));
    const sum = numbers.reduce((acc, curr) => acc + curr, 0);
    const average = sum / numbers.length || 0;
    result4.textContent = `Средний: ${average}`;
});

// Задание 5
const fullNameInput = document.getElementById('fullName');
const surnameInput = document.getElementById('surname');
const firstNameInput = document.getElementById('firstName');
const patronymicInput = document.getElementById('patronymic');

fullNameInput.addEventListener('blur', function() {
    const fullName = fullNameInput.value.split(' ');
    surnameInput.value = fullName[0] || '';
    firstNameInput.value = fullName[1] || '';
    patronymicInput.value = fullName[2] || '';
});

// Задание 6
const input6 = document.getElementById('input6');

input6.addEventListener('blur', function() {
    const capitalizedWords = input6.value.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    input6.value = capitalizedWords;
});

// Задание 7
const textInput7 = document.getElementById('textInput7');
const wordCount = document.getElementById('wordCount');

textInput7.addEventListener('blur', function() {
    const text = textInput7.value.trim();
    const wordArray = text.split(/\s+/);
    const count = wordArray.length;
    wordCount.textContent = `Количество слов: ${count}`;
});

// Задание 8
const dateInput8 = document.getElementById('dateInput8');

dateInput8.addEventListener('blur', function() {
    const dateString = dateInput8.value;
    const parts = dateString.split('.');
    if (parts.length === 3) {
        const formattedDate = parts[2] + '-' + parts[1] + '-' + parts[0];
        dateInput8.value = formattedDate;
    }
});

// Задание 9
const wordInput9 = document.getElementById('wordInput9');
const checkButton = document.getElementById('checkButton');
const result9 = document.getElementById('result9');

checkButton.addEventListener('click', function() {
    const word = wordInput9.value.toLowerCase();
    const reversedWord = word.split('').reverse().join('');
    if (word === reversedWord) {
        result9.textContent = 'Да, это палиндром!';
    } else {
        result9.textContent = 'Нет, это не палиндром.';
    }
});

// Задание 10
const numberInput10 = document.getElementById('numberInput10');
const result10 = document.getElementById('result10');

numberInput10.addEventListener('blur', function() {
    const number = numberInput10.value;
    if (number.includes('3')) {
        result10.textContent = 'Число содержит цифру 3.';
    } else {
        result10.textContent = 'Число не содержит цифры 3.';
    }
});

// Задание 11
const paragraphs = document.querySelectorAll('p');
const numberButton11 = document.getElementById('numberButton11');

numberButton11.addEventListener('click', function() {
    paragraphs.forEach((paragraph, index) => {
        paragraph.textContent +=  $(index + 1);
    });
});


// Задание 12
const links = document.querySelectorAll('a');
links.forEach(link => {
    const href = link.getAttribute('href');
    link.textContent +=  ($(href));
});

// Задание 13
const links13 = document.querySelectorAll('a');

links13.forEach(link => {
    const href = link.getAttribute('href');
    if (href.startsWith('http://')) {
        link.textContent += ' →';
    }
});

// Задание 14
const numberSpans = document.querySelectorAll('.number');

numberSpans.forEach(span => {
    const number = parseInt(span.textContent);
    span.addEventListener('click', function() {
        span.textContent = number * number;
    });
});

// Задание 15
const dateInput15 = document.getElementById('dateInput15');
const dayOfWeek = document.getElementById('dayOfWeek');

dateInput15.addEventListener('blur', function() {
    const dateString = dateInput15.value;
    const date = new Date(dateString);
    const options = { weekday: 'long' };
    const dayName = new Intl.DateTimeFormat('en-US', options).format(date);
    dayOfWeek.textContent = `Day of the week: ${dayName}`;
});

// Задание 16
const input16 = document.getElementById('input16');
const plusButton = document.getElementById('plusButton');
const minusButton = document.getElementById('minusButton');

plusButton.addEventListener('click', function() {
    input16.value = parseInt(input16.value) + 1;
});

minusButton.addEventListener('click', function() {
    const value = parseInt(input16.value);
    if (value > 0) {
        input16.value = value - 1;
    }
});

// Задание 17
const clickCountInput = document.getElementById('clickCountInput');
const clickCount = document.getElementById('clickCount');
let totalClicks = 0;

clickCountInput.addEventListener('input', function() {
    totalClicks = parseInt(clickCountInput.value) || 0;
    clickCount.textContent = `Total clicks: ${totalClicks}`;
});

// Задание 18
const trimDivs = document.querySelectorAll('.trimDiv');

trimDivs.forEach(div => {
    const text = div.textContent.trim();
    if (text.length > 10) {
        div.textContent = text.substring(0, 10) + '...';
    }
});

// Задание 19
const randomStringInput = document.getElementById('randomStringInput');
const generateRandomStringButton = document.getElementById('generateRandomString');

generateRandomStringButton.addEventListener('click', function() {
    const randomString = Math.random().toString(36).substring(2, 10);
    randomStringInput.value = randomString;
});

// Задание 20
const shuffleStringInput = document.getElementById('shuffleStringInput');
const shuffleStringButton = document.getElementById('shuffleStringButton');

shuffleStringButton.addEventListener('click', function() {
    const shuffledString = shuffleString(shuffleStringInput.value);
    shuffleStringInput.value = shuffledString;
});

function shuffleString(string) {
    const array = string.split('');
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array.join('');
}

// Задание 21
const fahrenheitInput = document.getElementById('fahrenheitInput');
const convertButton = document.getElementById('convertButton');
const celsiusOutput = document.getElementById('celsiusOutput');

convertButton.addEventListener('click', function() {
    const fahrenheit = parseFloat(fahrenheitInput.value);
    const celsius = (fahrenheit - 32) * 5 / 9;
    celsiusOutput.textContent = `Temperature in Celsius: ${celsius.toFixed(2)}`;
});

// Задание 22
const factorialInput = document.getElementById('factorialInput');
const factorialButton = document.getElementById('factorialButton');
const factorialOutput = document.getElementById('factorialOutput');

factorialButton.addEventListener('click', function() {
    const number = parseInt(factorialInput.value);
    if (number >= 0) {
        const factorial = calculateFactorial(number);
        factorialOutput.textContent = `Factorial: ${factorial}`;
    } else {
        factorialOutput.textContent = 'Please enter a non-negative integer.';
    }
});


function calculateFactorial(n) {
    if (n === 0 || n === 1) {
        return 1;
    } else {
        return n * calculateFactorial(n - 1);
    }
}

// Задание 23
const coefficientA = document.getElementById('coefficientA');
const coefficientB = document.getElementById('coefficientB');
const coefficientC = document.getElementById('coefficientC');
const solveEquationButton = document.getElementById('solveEquationButton');
const equationOutput = document.getElementById('equationOutput');

solveEquationButton.addEventListener('click', function() {
    const a = parseFloat(coefficientA.value);
    const b = parseFloat(coefficientB.value);
    const c = parseFloat(coefficientC.value);

    const discriminant = b * b - 4 * a * c;

    if (discriminant > 0) {
        const root1 = (-b + Math.sqrt(discriminant)) / (2 * a);
        const root2 = (-b - Math.sqrt(discriminant)) / (2 * a);
        equationOutput.textContent = `Roots: ${root1.toFixed(2)} and ${root2.toFixed(2)}`;
    } else if (discriminant === 0) {
        const root = -b / (2 * a);
        equationOutput.textContent = `Root: ${root.toFixed(2)}`;
    } else {
        equationOutput.textContent = 'No real roots';
    }
});